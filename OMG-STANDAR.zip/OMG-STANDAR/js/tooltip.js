$(document).ready(function(){$('#IngresoLog').tooltip('show');$('#IngresoLog').tooltip('hide');});

