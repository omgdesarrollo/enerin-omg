 

<div id="empleados">
<iframe src="EmpleadosView.php" style="width: 100%; height: 400px;margin-top: 20px;margin-left: 10px;" name="formularios"></iframe>
</div>


<div id="temas">
<iframe src="TemasView.php" style="width: 100%; height: 400px;margin-top: 20px;margin-left: 10px;" name="formularios"></iframe>
</div>


<div id="requisitos">
<iframe src="RequisitosView.php" style="width: 100%; height: 400px;margin-top: 20px;margin-left: 10px;" name="formularios"></iframe>
</div>


<div id="documentos">
<iframe src="DocumentosView.php" style="width: 100%; height: 400px;margin-top: 20px;margin-left: 10px;" name="formularios"></iframe>
</div>



<div id="asignaciontemasrequisitos">
    <iframe src="AsignacionTemasRequisitosView.php" style="width: 100%; height: 400px;margin-top: 20px;margin-left: 10px;" name="formularios"></iframe>
</div>


<div id="asignaciondocumentostemas">
    <iframe src="AsignacionDocumentosTemasView.php" style="width: 100%; height: 400px;margin-top: 20px;margin-left: 10px;" name="formularios"></iframe>
</div>



<div id="cumplimientos">
<iframe src="CumplimientosView.php" style="width: 100%; height: 400px;margin-top: 20px;margin-left: 10px;" name="formularios"></iframe>
</div>


<div id="clausulas">
<iframe src="ClausulasView.php" style="width: 100%; height: 400px;margin-top: 20px;margin-left: 10px;" name="formularios"></iframe>
</div>


<div id="entidadesReguladoras">
<iframe src="EntidadesReguladorasView.php" style="width: 100%; height: 400px;margin-top: 20px;margin-left: 10px;" name="formularios"></iframe>
</div>


<div id="documentosEntrada">
<iframe src="DocumentoEntradaView.php" style="width: 100%; height: 400px;margin-top: 20px;margin-left: 10px;" name="formularios"></iframe>
</div>


<div id="documentosSalida">
<iframe src="DocumentoSalidaView.php" style="width: 100%; height: 400px;margin-top: 20px;margin-left: 10px;" name="formularios"></iframe>
</div>


<div id="seguimientoentradas">
    <iframe src="SeguimientoEntradaView.php" style="width: 100%; height: 400px;margin-top: 20px;margin-left: 10px;" name="formularios"></iframe>
</div>


<div id="informegerencial">
    <iframe src="InformeGerencialView.php" style="width: 100%; height: 400px;margin-top: 20px;margin-left: 10px;" name="formularios"></iframe>
</div>