<?php
header("location: OMG/View/login.php");
?>