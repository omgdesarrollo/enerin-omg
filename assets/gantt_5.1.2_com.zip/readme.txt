@license

dhtmlxGantt v.5.1.2 Professional
This software is covered by DHTMLX Commercial License. Usage without proper license is prohibited.

(c) Dinamenta, UAB.


Useful links
-------------

- Online  documentation
	https://docs.dhtmlx.com/gantt/

- Downloadable documentation
	CHM version
		https://docs.dhtmlx.com/chm/gantt.chm.zip
	HTML version
		http://dhtmlx.com/x/download/regular/dhtmlxgantt_docs_html.zip
	
- Support forum
	https://forum.dhtmlx.com/viewforum.php?f=15