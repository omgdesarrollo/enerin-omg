/*!
 * @license
 * 
 * dhtmlxGantt v.5.1.2 Professional
 * This software is covered by DHTMLX Commercial License. Usage without proper license is prohibited.
 * 
 * (c) Dinamenta, UAB.
 * 
 */
!function(e){function n(o){if(t[o])return t[o].exports;var r=t[o]={i:o,l:!1,exports:{}};return e[o].call(r.exports,r,r.exports,n),r.l=!0,r.exports}var t={};n.m=e,n.c=t,n.d=function(e,t,o){n.o(e,t)||Object.defineProperty(e,t,{configurable:!1,enumerable:!0,get:o})},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,"a",t),t},n.o=function(e,n){return Object.prototype.hasOwnProperty.call(e,n)},n.p="",n(n.s=14)}({14:function(e,n,t){e.exports=t(15)},15:function(e,n){gantt.locale={date:{month_full:[" Januar"," Februar"," März "," April"," Mai"," Juni"," Juli"," August"," September "," Oktober"," November "," Dezember"],month_short:["Jan","Feb","Mär","Apr","Mai","Jun","Jul","Aug","Sep","Okt","Nov","Dez"],day_full:["Sonntag","Montag","Dienstag"," Mittwoch"," Donnerstag","Freitag","Samstag"],day_short:["So","Mo","Di","Mi","Do","Fr","Sa"]},labels:{new_task:"Neue Aufgabe",dhx_cal_today_button:"Heute",day_tab:"Tag",week_tab:"Woche",month_tab:"Monat",new_event:"Neuer eintrag",icon_save:"Speichern",icon_cancel:"Abbrechen",icon_details:"Details",icon_edit:"Ändern",icon_delete:"Löschen",confirm_closing:"",confirm_deleting:"Der Eintrag wird gelöscht",section_description:"Beschreibung",section_time:"Zeitspanne",section_type:"Type",column_wbs:"PSP",column_text:"Task-Namen",column_start_date:"Startzeit",column_duration:"Dauer",column_add:"",link:"Link",confirm_link_deleting:"werden gelöscht",link_start:"(starten)",link_end:"(ende)",type_task:"Task",type_project:"Project",type_milestone:"Milestone",minutes:"Minuten",hours:"Stunden",days:"Tage",weeks:"Wochen",months:"Monate",years:"Jahre",message_ok:"OK",message_cancel:"Abbrechen"}}}});
//# sourceMappingURL=locale_de.js.map