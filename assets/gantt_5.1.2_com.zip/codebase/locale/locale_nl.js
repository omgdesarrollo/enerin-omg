/*!
 * @license
 * 
 * dhtmlxGantt v.5.1.2 Professional
 * This software is covered by DHTMLX Commercial License. Usage without proper license is prohibited.
 * 
 * (c) Dinamenta, UAB.
 * 
 */
!function(e){function n(a){if(t[a])return t[a].exports;var r=t[a]={i:a,l:!1,exports:{}};return e[a].call(r.exports,r,r.exports,n),r.l=!0,r.exports}var t={};n.m=e,n.c=t,n.d=function(e,t,a){n.o(e,t)||Object.defineProperty(e,t,{configurable:!1,enumerable:!0,get:a})},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,"a",t),t},n.o=function(e,n){return Object.prototype.hasOwnProperty.call(e,n)},n.p="",n(n.s=42)}({42:function(e,n,t){e.exports=t(43)},43:function(e,n){gantt.locale={date:{month_full:["Januari","Februari","Maart","April","Mei","Juni","Juli","Augustus","September","Oktober","November","December"],month_short:["Jan","Feb","mrt","Apr","Mei","Jun","Jul","Aug","Sep","Okt","Nov","Dec"],day_full:["Zondag","Maandag","Dinsdag","Woensdag","Donderdag","Vrijdag","Zaterdag"],day_short:["Zo","Ma","Di","Wo","Do","Vr","Za"]},labels:{new_task:"Nieuwe taak",dhx_cal_today_button:"Vandaag",day_tab:"Dag",week_tab:"Week",month_tab:"Maand",new_event:"Nieuw item",icon_save:"Opslaan",icon_cancel:"Annuleren",icon_details:"Details",icon_edit:"Bewerken",icon_delete:"Verwijderen",confirm_closing:"",confirm_deleting:"Item zal permanent worden verwijderd, doorgaan?",section_description:"Beschrijving",section_time:"Tijd periode",section_type:"Type",column_wbs:"WBS",column_text:"Taak omschrijving",column_start_date:"Startdatum",column_duration:"Duur",column_add:"",link:"Koppeling",confirm_link_deleting:"zal worden verwijderd",link_start:" (start)",link_end:" (eind)",type_task:"Task",type_project:"Project",type_milestone:"Milestone",minutes:"minuten",hours:"uren",days:"dagen",weeks:"weken",months:"maanden",years:"jaren",message_ok:"OK",message_cancel:"Annuleren"}}}});
//# sourceMappingURL=locale_nl.js.map