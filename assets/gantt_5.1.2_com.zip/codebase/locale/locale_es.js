/*!
 * @license
 * 
 * dhtmlxGantt v.5.1.2 Professional
 * This software is covered by DHTMLX Commercial License. Usage without proper license is prohibited.
 * 
 * (c) Dinamenta, UAB.
 * 
 */
!function(e){function n(t){if(o[t])return o[t].exports;var r=o[t]={i:t,l:!1,exports:{}};return e[t].call(r.exports,r,r.exports,n),r.l=!0,r.exports}var o={};n.m=e,n.c=o,n.d=function(e,o,t){n.o(e,o)||Object.defineProperty(e,o,{configurable:!1,enumerable:!0,get:t})},n.n=function(e){var o=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(o,"a",o),o},n.o=function(e,n){return Object.prototype.hasOwnProperty.call(e,n)},n.p="",n(n.s=18)}({18:function(e,n,o){e.exports=o(19)},19:function(e,n){gantt.locale={date:{month_full:["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"],month_short:["Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"],day_full:["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"],day_short:["Dom","Lun","Mar","Mié","Jue","Vie","Sáb"]},labels:{new_task:"Nueva tarea",dhx_cal_today_button:"Hoy",day_tab:"Día",week_tab:"Semana",month_tab:"Mes",new_event:"Nuevo evento",icon_save:"Guardar",icon_cancel:"Cancelar",icon_details:"Detalles",icon_edit:"Editar",icon_delete:"Eliminar",confirm_closing:"",confirm_deleting:"El evento se borrará definitivamente, ¿continuar?",section_description:"Descripción",section_time:"Período",section_type:"Tipo",column_wbs:"EDT",column_text:"Tarea",column_start_date:"Inicio",column_duration:"Duración",column_add:"",link:"Enlace",confirm_link_deleting:"será borrada",link_start:" (inicio)",link_end:" (fin)",type_task:"Tarea",type_project:"Proyecto",type_milestone:"Hito",minutes:"Minutos",hours:"Horas",days:"Días",weeks:"Semanas",months:"Meses",years:"Años",message_ok:"OK",message_cancel:"Cancelar"}}}});
//# sourceMappingURL=locale_es.js.map