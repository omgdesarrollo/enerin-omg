/*!
 * @license
 * 
 * dhtmlxGantt v.5.1.2 Professional
 * This software is covered by DHTMLX Commercial License. Usage without proper license is prohibited.
 * 
 * (c) Dinamenta, UAB.
 * 
 */
!function(e){function t(o){if(n[o])return n[o].exports;var a=n[o]={i:o,l:!1,exports:{}};return e[o].call(a.exports,a,a.exports,t),a.l=!0,a.exports}var n={};t.m=e,t.c=n,t.d=function(e,n,o){t.o(e,n)||Object.defineProperty(e,n,{configurable:!1,enumerable:!0,get:o})},t.n=function(e){var n=e&&e.__esModule?function(){return e.default}:function(){return e};return t.d(n,"a",n),n},t.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},t.p="",t(t.s=56)}({56:function(e,t,n){e.exports=n(57)},57:function(e,t){gantt.locale={date:{month_full:["Január","Február","Marec","Apríl","Máj","Jún","Júl","August","September","Október","November","December"],month_short:["Jan","Feb","Mar","Apr","Máj","Jún","Júl","Aug","Sept","Okt","Nov","Dec"],day_full:["Nedeľa","Pondelok","Utorok","Streda","Štvrtok","Piatok","Sobota"],day_short:["Ne","Po","Ut","St","Št","Pi","So"]},labels:{new_task:"Nová úloha",dhx_cal_today_button:"Dnes",day_tab:"Deň",week_tab:"Týždeň",month_tab:"Mesiac",new_event:"Nová udalosť",icon_save:"Uložiť",icon_cancel:"Späť",icon_details:"Detail",icon_edit:"Edituj",icon_delete:"Zmazať",confirm_closing:"Vaše zmeny nebudú uložené. Skutočne?",confirm_deleting:"Udalosť bude natrvalo vymazaná. Skutočne?",section_description:"Poznámky",section_time:"Doba platnosti",section_type:"Type",column_wbs:"WBS",column_text:"Task name",column_start_date:"Start time",column_duration:"Duration",column_add:"",link:"Link",confirm_link_deleting:"will be deleted",link_start:" (start)",link_end:" (end)",type_task:"Task",type_project:"Project",type_milestone:"Milestone",minutes:"Minutes",hours:"Hours",days:"Days",weeks:"Week",months:"Months",years:"Years",message_ok:"OK",message_cancel:"Späť"}}}});
//# sourceMappingURL=locale_sk.js.map